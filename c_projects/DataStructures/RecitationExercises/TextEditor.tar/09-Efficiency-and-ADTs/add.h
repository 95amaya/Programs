int SearchStrBuffer(bufferADT buffer, char* str)
{
	return 0;
}
void ReplaceCharInBuffer(bufferADT buffer, char oldch, char newch)
{
	return;
}

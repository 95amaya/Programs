#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct Point
{
	double x;
	double y;
} PointT;

typedef struct Rect
{
	PointT location;
	char color;
	double w; //width;
	double h; //height;
} RectT;

// Private functions
int chk_overlap(RectT *r1, RectT *r2);
int isValid(int iScanfCount);

int main(void) {
	RectT a, b, *recs;
	int i, aCounter, bCounter, abCounter, iScanfCount;
        aCounter = bCounter = abCounter = 0;
	
   	/* Intializes random number generator */
   	time_t t;
   	srand((unsigned) time(&t));
   	
        recs = (RectT *) malloc(50 * sizeof(RectT));
        if (recs==NULL) printf("No memory available\n");
	
        for(i = 0; i < 2; i++)
        {
            printf("Square %c\n", i == 0 ? 'A' : 'B');
            
            printf("\tStarting X: ");
            if(i == 0)
   	        iScanfCount = scanf("%lf", &a.location.x);
            else
   	        iScanfCount = scanf("%lf", &b.location.x);
            
            if(!isValid(iScanfCount))
                return 1;

            printf("\tStarting Y: ");
            if(i == 0)
   	        iScanfCount = scanf("%lf", &a.location.y);
            else
   	        iScanfCount = scanf("%lf", &b.location.y);
            
            if(!isValid(iScanfCount))
                return 1;
            
            printf("\tHeight: ");
            if(i == 0)
   	        iScanfCount = scanf("%lf", &a.h);
            else
   	        iScanfCount = scanf("%lf", &b.h);
            
            if(!isValid(iScanfCount))
                return 1;


            printf("\tWidth: ");
            if(i == 0)
   	        iScanfCount = scanf("%lf", &a.w);
            else
   	        iScanfCount = scanf("%lf", &b.w);
            
            if(!isValid(iScanfCount))
                return 1;
        }	
	
        printf("Overlap (true or False)? %i\n", chk_overlap(&a,&b));
	
	for(i = 0; i < 50; i++)
	{
            recs[i].location.x = rand() % 30;
            recs[i].location.y = rand() % 30;
            recs[i].h = rand() % 9 + 1;
            recs[i].w = rand() % 9 + 1;
   	   
           // For debugging purposes
           printf("Square #%i (x, y) Width X Height: (%.2lf, %.2lf) %.2lf X %.2lf\n"
            , i+2, recs[i].location.x, recs[i].location.y
            , recs[i].h, recs[i].w);
	
            //Check for a overlap
            if(chk_overlap(&a, &recs[i]) && chk_overlap(&b, &recs[i]))
                abCounter++;
            if(chk_overlap(&a, &recs[i]))
                aCounter++;
            if(chk_overlap(&b, &recs[i]))
                bCounter++;

            // Overlap Check
            //if(chk_overlap(&a, &recs[i]) || chk_overlap(&b, &recs[i]))
              //  printf("OVERLAP!\n");
        }
        printf("----------------------------------------------------------\n");
        printf("A Overlap: %i   B Overlap: %i   A and B Overlap: %i\n"
        , aCounter, bCounter, abCounter);
	
        free(recs);
	return 0;
}

int isValid(int iScanfCount)
{
    if(iScanfCount != 1)
    {
        printf("Invalid Number\n");
        return 0;
    }
    return 1;
}

int chk_overlap(RectT *r1, RectT *r2)
{
	double iMinX = r1->location.x;
	double iMinY = r1->location.y;
	
	double iMaxX = r1->location.x + r1->w;
	double iMaxY = r1->location.y + r1->h;
	
	if(r2->location.y <= iMaxY && r2->location.x <= iMaxX // checks for max and min overlap
	   && r2->location.y+r2->h >= iMinY && r2->location.x+r2->w >= iMinX)
	{
		return 1;
	}
	return 0;
}

/**************************** driver.c  ***********************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "list.h"

int main()
{
	listADT X,Y,Z;
	int i, rand, iUser, iCheck = 0;
	X = NewList();
	Y = NewList();
    srand((int) time(NULL));
		
	/*** Populate a Sorted and Unsorted list with random ints ***/
	//printf("Random Sequence: ");
	for(i = 0; i < 6; i++)
	{
		rand = RandomInteger(1,20);
		//printf("%d ", rand);
		list_insert_sorted(X, rand); //  why not list_insert_sorted(&X, 9)
		list_insert_unsorted(Y, rand);
	}
	printf("\n");
	
	/*** Print Both Lists ***/
	list_print_values(Y, "Unsorted (Y)");
	list_print_values(X, "Sorted (X)");
	
	/*** Print Average ***/
	printf("Average: %.2lf\n", list_average(X));

	/*** Ask User to enter a value to remove from both list ***/
	do{  
		printf("Enter value to be removed from lists: ");
		iCheck = scanf("%d", &iUser); 
		while(getchar() != '\n');
	} while(iCheck != 1);
	list_delete_by_value( X, iUser);
	list_delete_by_value( Y, iUser);

	/*** Print Both Lists ***/
	list_print_values(Y, "Unsorted (Y)");
	list_print_values(X, "Sorted (X)");

	/*** Print Average of Both Lists ***/
	printf("Average Y: %.2lf\n", list_average(Y));
	printf("Average X: %.2lf\n", list_average(X));

	/*** Copy 3 elements of X into new list Z ***/
	Z = list_n_copy(X, 3);
	//printf("Z: %p\n", Z);
	
	/*** Print List Z ***/
	list_print_values(Z, "Z");
	
	/*** Print Average of List Z ***/
	printf("Average Z: %.2lf\n", list_average(Z));

	/*** Free Lists ***/
	FreeList(X);
	FreeList(Y);
	FreeList(Z);
	return 0;
}


int RandomInteger(int low, int high)
{
    int k;
    double d;

    d = (double) rand() / ((double) RAND_MAX + 1);
    k = (int) (d * (high - low + 1));
    return (low + k);
}


/******************************* list.c ***********************/
#include <stdio.h>
#include <stdlib.h>
#include "list.h"

typedef struct point {
   listElementT x; 
   struct point *next;
} myDataT;

struct listCDT {
	myDataT *start; // myDataT *header;
	myDataT *end;   // myDataT *foother;
};

listADT NewList()
{
   listADT tmp;

   tmp = (listADT)malloc(sizeof(struct listCDT)); // New(listADT);
   if (tmp==NULL) return NULL;                  
   tmp->start = tmp->end = NULL;
   return tmp;
}

void list_insert_sorted(listADT a, int value)
{
	myDataT *b, *prev, *curr;

	b = (myDataT *) malloc(sizeof(myDataT)); 
	if (b==NULL) return;
	b->x = value;   
	b->next = NULL;

	prev = NULL;
	curr = a->start; 
	while(curr) {
	   if (curr->x >= b->x ) break;
	   prev = curr;
	   curr = curr->next;
	}
	if(prev == NULL) {
	   b->next = a->start;
	   a->start = b;
	} else{ 
	   b->next = prev->next;
	   prev->next = b;
	}
	if (b->next == NULL){
		a->end = b;
	}
}

// add val the end of the link list
void list_insert_unsorted(listADT a, int value) 
{ 
	myDataT *b;

	b = (myDataT *) malloc(sizeof(myDataT)); 
	if (b==NULL) return;
	b->x = value;   
	b->next = NULL;

	if(a->start == NULL) {
		a->start = b;
	} else{ 
	   a->end->next = b;   
	}
	a->end = b;
}

void FreeList(listADT a)
{
	myDataT *tmp = a->start;
	myDataT *tmpNext = tmp;
	//printf("Freed: ");
	while(tmpNext != NULL)
	{
		//printf("%p   ", tmp);
		tmpNext = tmp->next;
		free(tmp);
		tmp = tmpNext;
	}
	free(a);
}

void list_print_values(listADT a, char *name)
{
	myDataT *tmp = a->start;

	printf("%s: ", name);
	while(tmp->next != NULL)
	{
		//printf("%d (%p)(%p), ", tmp->x, tmp, tmp->next);
		printf("%d, ", tmp->x);
		tmp = tmp->next;
	}
	printf("%d\n", tmp->x);
}

double list_average(listADT a)
{
	myDataT *tmp = a->start;
	int iSum = 0, iCount = 0;
	
	while(tmp != NULL)
	{
		iSum += tmp->x;
		tmp = tmp->next;
		iCount++;
	}
	
	if(iCount == 0)
		return -1;
	return (double) iSum / iCount;
}
void list_delete_by_value(listADT a, listElementT x)
{
	myDataT *tmp = a->start;
	myDataT *tmpPrev = tmp;
	
	while(tmp != NULL)
	{
		if(tmp->x == x)
		{
			if(tmp == a->start)
				a->start = tmp->next;
			else
				tmpPrev->next = tmp->next;
			
			if(tmp == a->end)
				a->end = tmpPrev;
				
			free(tmp);
			return;
		}
		tmpPrev = tmp;
		tmp = tmp->next;
	}
	return;
}

// make a new list, copy the first n values from list a
listADT list_n_copy(listADT a, int n)
{
	listADT copy = NewList();
	myDataT *tmp = a->start;

	while(n >= 1 && tmp != NULL)
	{
		//printf("Vale to copy: %d\n", tmp->x);
		list_insert_unsorted(copy, tmp->x);	
		tmp = tmp->next;
		n--;
	}
	//printf("Copy: %p\t", copy);
	return copy;
}


#include <stdio.h>
#include <string.h>
/* #include "genlib.h"  */
#include "random.h"

void playHiLo(int iNum[]);
void getSecret(int iSecret[]);
int getGuess(char input[]);
int checkGuess(int iNum[], char *cUserDigit);

int main(void)
{
   int secret[4];			/*  Declare variables */ 
    
   Randomize();
	
   while(1){
     secret[0] = RandomInteger(1,9);
     secret[1] = RandomInteger(0,9);  
     secret[2] = RandomInteger(0,9);  
     secret[3] = RandomInteger(0,9);  
     
     playHiLo(secret);
   }
   return 0;
}

void playHiLo(int iNum[])
{
    int iGuessMax = 0, i, iCorrectGuess = 0;
    char input[5];

    /* Print Secret for Check
    printf("Secret = ");
    for(i = 0; i < 4; i++)
    {
        printf("%d", iNum[i]);
    }*/

    /* Enter check while loop */
    while(!iCorrectGuess && iGuessMax != 40)
    {
        /* check for correct input */
        if(!getGuess(input))
        {
            printf("Incorrect Input. Guess again\n");
            continue;
        }

        /* check users guess */
        iCorrectGuess = checkGuess(iNum, &input[0]);

        /* increment guess max counter (40 attempt max) */
        iGuessMax++;
    }

    /* print end game result */
    if(iCorrectGuess)
      printf("Congradulations! You're Correct!\n");
    else
      printf("Sorry! \n Try again with a new secret number\n");

}

int getGuess(char input[])
{
    int i;

    printf("\nGuess: ");
    if(scanf("%4s", input) != 1)
    {
        printf("Incorrect Input. Guess again\n");
        return 0;
    }
    else
    {
        /* Echo User Input for Debugging Purposes */
        //printf("\nUser Input = %s\n", input);
        char *checkDigit = &input[0];
        for(i = 0; i < 3; i++)
        {
            /* Check if any of the digits are characters (ASCII > 57 or '9') */
            if(*checkDigit > 57)
            {
                printf("Incorrect Input. Guess again\n");
                return 0;
            }
            checkDigit++;
        }
    }
    return 1;
}

int checkGuess(int iNum[], char *cUserDigit)
{
    int iCounter1 = 0, iCounter2 = 0, i, j, k;
    char cDigitCheck = 'a';
    
    /* Echo firt character of User input for debugging purposes */
    //printf("User First Digit = %c\n", *cUserDigit);

    for(i = 0; i < 4; i++)
    {
        /* Compare secret # digits to user input digits */
        //printf("Secret Digit: %d\tUser Digit: %c\n", iNum[i], *cUserDigit);
        
        if(iNum[i] == (*cUserDigit - '0'))
            iCounter1++;
        else
        {
            for(j = 0; j < 4; j++)
            {
                if(j == i)
                    continue;
                else
                {
                    if(iNum[j] == (*cUserDigit - '0'))
                        iCounter2++;                       
                }
            }
        }
        cUserDigit++;
    }

    printf("%d %s in place\n", iCounter1, iCounter1 == 1 ? "digit is":"digits are");
    printf("%d %s out of place\n", iCounter2, iCounter2 == 1 ? "digit is":"digits are");
    printf("%d %s not exist\n", 4 -(iCounter1 + iCounter2), 4 -(iCounter1 + iCounter2) == 1 ? "digit does":"digits do");
    
    if(iCounter1 == 4)
      return 1;
    return 0;
}

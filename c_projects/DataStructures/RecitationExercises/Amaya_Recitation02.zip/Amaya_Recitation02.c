#include <stdio.h>

void increaseA(int val){ val++;}
void increaseB(int *pval) { pval++;}
void increaseC(int *pval) { *pval++; }
void increaseD(int *pval) { (*pval)++; }

void exchange(int *pVal1, int *pVal2);

int main(void) {
	int a, b, c, temp, sum;
	int *pa, *pb, *pc;
	int **ppa, **ppb, **ppc;

	a = 10;	b = 20; c = 30;
	
	pa = &a; pb = &b, pc = &c;
	
	ppa = &pa; ppb = &pb, ppc = &pc;
	
	printf("a = %d, b = %d, c = %d\n", a, *pb, **ppc);
	
	sum = a + *pb + **ppc;
	
	printf("Sum = %d\n", sum);

	temp = *pa;
	*pa = **ppb;
	**ppb = temp;
	
	printf("a = %d, b = %d\n", a, b);
	
	int *ptemp;
	
	ptemp = *ppb;	// &pb
	*ppb = pa;		// pb = &pa
	pa = ptemp;		// pa = &pb
	
	printf("*pa = %d, **ppb = %d\n", *pa, **ppb);
	printf("a = %d, b = %d\n", a, b);
	
	/*	
		Pointers switch but contents of pointers do not.
		That is why content stays the same while indirect addressing
		leads to different results.
										*/
	
	// call by value increasing a copy of a
	increaseA(a);
	printf("\n1.) a = %d\n", a);
	
	// call by reference increasing address of a but not content
	increaseB(&a);	
	printf("2.) a = %d\n", a);
	
	// call by reference increasing address BEFORE dereferencing pointer (precedence)
	increaseC(&a);	
	printf("3.) a = %d\n", a);
	
	// call by reference increasing content AFTER dereferencing pointer (precedence) 
	increaseD(&a);	//
	printf("4.) a = %d\n\n", a);
	
	// before exchange is executed
	printf("Before\n");
	printf("&pa = %p pa = %p *pa = %d\n", &pa, pa, *pa);
	printf("&pb = %p pb = %p *pb = %d\n\n", &pb, pb, *pb);
	
	// call by reference passing the address of pointers pa and pb
	exchange(&pa,&pb);
	printf("After 1\n");
	printf("&pa = %p pa = %p *pa = %d\n", &pa, pa, *pa);
	printf("&pb = %p pb = %p *pb = %d\n", &pb, pb, *pb);
	// works because addresses pa and pb are being swapped in exchange()
	
	// call by reference passing the address of pointer pa and pointer ppb which holds the address of pb
	exchange(&pa, ppb);
	printf("After 2\n");
	printf("&pa = %p pa = %p *pa = %d\n", &pa, pa, *pa);
	printf("&pb = %p pb = %p *pb = %d\n", &pb, pb, *pb);
	// works because address pa is being swapped with the derefenced ppb, which also holds the address of pb
	
	// call by reference passing ponters ppa and ppb, which holds addresses of pa and pb
	exchange(ppa, ppb);
	printf("After 3\n");
	printf("&pa = %p pa = %p *pa = %d\n", &pa, pa, *pa);
	printf("&pb = %p pb = %p *pb = %d\n\n", &pb, pb, *pb);
	// works because pointers ppa and ppb both hold addresses of pa and pb so when the are dereferenced
	// and swapped the addresses of pa and pb are swapped as well
	return 0;
}

// Passing in address to pointers as pointers therefore you need to dereference to get pointer addresses.
void exchange(int *pVal1, int *pVal2)
{
	int *ptemp;
	
	*ptemp = *pVal1;
	*pVal1 = *pVal2;
	*pVal2 = *ptemp;
	return;
}

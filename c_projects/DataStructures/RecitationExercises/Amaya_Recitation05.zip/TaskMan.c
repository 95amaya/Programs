/*******************************************************************
File: TaskMan.c
Written By: Michael Amaya
Date: 9/22/2016

Purpose:
    Performs critical path analysis for project managing.

Command Line Arguments:
    run -input InputFilename -output OutputFilename

Input:  Task management table
        
        Event   Task    Number of Days
        1       15      3
        1       27      6
        1       36      4
        2       15      5
        3       18      4
        3       26      1
        4       15      2
        4       26      7
        4       27      7
        5       16      4

Output: Critical path analysis table

        completion timetable
        ------------------------------------------------
        Event   Tasks  Max Days
        -----   -----  --------
          1       3       6
          2       1       5
          3       2       4
          4       3       7
          5       1       4
        ------------------------------------------------
        Total number of days to finish the project: 26 days 6


***********************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/**** constants ****/
// Maximum sizes
#define MAX_LINE_SIZE 50
#define MAX_FILE_SIZE 100 // max # of lines in file

// boolean
#define FALSE           0
#define TRUE            1

/*  Error Messages */
#define ERR_MISSING_SWITCH          "missing switch"
#define ERR_EXPECTED_SWITCH         "expected switch, found"
#define ERR_MISSING_ARGUMENT        "missing argument for"
#define ERR_INPUT_FILENAME          "invalid input file name"
#define ERR_OUTPUT_FILENAME         "invalid output file name"

/* program return codes */
#define ERR_COMMAND_LINE_SYNTAX     -1      // invalid command line syntax
#define USAGE_ONLY                  -2      // show usage only
#define ERROR_PROCESSING            -3

/* Private Error Handling functions  */
void exitError(char *pszMessage, char *pszDiagnosticInfo);
void exitUsage(int iArg, char *pszMessage, char *pszDiagnosticInfo);

FILE *pFileData;               // stream Input for input data
FILE *pFileOut;

void processCommandSwitches(int argc, char *argv[], char **ppszFileData, char **ppszFileOut);
void getData();

int main(int argc, char *argv[])
{
    char *pszFileData = NULL;   // Declare input data file name pointer
    char *pszFileOut  = NULL;   // Declare output data file name pointer

    // Process the command switches
    processCommandSwitches(argc, argv,  &pszFileData, &pszFileOut);
 
    // open input data file
    if (pszFileData == NULL)
        exitError(ERR_MISSING_SWITCH, "-i");
    
    // open input file to read data    
    pFileData = fopen(pszFileData, "r");     // Open book file to begin for processing
    if (pFileData == NULL)
        exitError(ERR_INPUT_FILENAME, pszFileData);
    
    ////////////// Output file info //////////////////////////
    // check for valid file name
    if (pszFileOut == NULL)
        exitError(ERR_MISSING_SWITCH, "-o");
    
    // open output file to write data
    pFileOut = fopen(pszFileOut, "w");    // Open customer file to begin for processing
    if (pFileOut == NULL)
        exitError(ERR_OUTPUT_FILENAME, pszFileOut);

    getData();

    fclose(pFileOut);                              // Close customer file end of processing
    fclose(pFileData);                              // Close book file

    return 0;
}

/***********************************************************************
void getData()

Purpose: 
    Processes input file and ouputs processed data into an output file.

It does this by getting each line of data and processing line by line
using a number of variables. The variables are updated each time there
is a switch of events. Then, the resulting data is written to an ouput
file.
************************************************************************/

void getData()
{
    char szInputBuffer[MAX_LINE_SIZE];
    int i = 0, iScanfCnt = 0, iTask = 0, iTaskCounter = 0;
    int iCurrEvent = 0, iFutEvent = 0, iDaysMax = 0, iDays = 0, iTotalDays = 0;
    
    fprintf(pFileOut, "Project Completion Timetable\n");
    fprintf(pFileOut, "----------------------------\n"); 
    fprintf(pFileOut, "%-8s%-8s%-8s\n", "Event", "Tasks", "Max Days"); 
    fprintf(pFileOut, "%-8s%-8s%-8s\n", "-----", "-----", "------");

    // Read the input data until EOF
    while (fgets(szInputBuffer, MAX_LINE_SIZE, pFileData) != NULL)
    {
        // check for max number of lines in file
        if (i >= MAX_FILE_SIZE)
            exitError("Too big of a file", szInputBuffer);

        iScanfCnt = sscanf(szInputBuffer, "%i %i %i\n", &iFutEvent, &iTask, &iDays);
        
        // for first line of data set current and future event to the same value
        if(i == 0)
            iCurrEvent = iFutEvent;

        // It should have populated all 3 variables, if not exit with an error.
        if (iScanfCnt < 3)
            exitError("Invalid line of data", szInputBuffer);
        else
        {
            // If the events change capture data in output file 
            if(iFutEvent != iCurrEvent)
            {
                fprintf(pFileOut, "%3i%8i%9i\n", iCurrEvent, iTaskCounter, iDaysMax);
                
                // Set or reset needed variables
                iTotalDays += iDaysMax;
                iCurrEvent = iFutEvent;
                iTaskCounter = iDaysMax = 0;
            }
            
            // check if current days is greater than the max for specific task
            if(iDays > iDaysMax)
                iDaysMax = iDays;

            // Valid data means update task counter
            iTaskCounter++;
        }
        i++;
    }
    
    // End of file reached with good data -> update total days and write variables to output file
    iTotalDays += iDaysMax;
    fprintf(pFileOut, "%3i%8i%9i\n", iCurrEvent, iTaskCounter, iDaysMax);
    fprintf(pFileOut, "-----------------------------\n");
    fprintf(pFileOut, "Total # of days to complete project: %i\n", iTotalDays);
}

/******************** processCommandSwitches *****************************
void processCommandSwitches(int argc, char *argv[], char **ppszFileData, char **ppszFileOut)
Purpose:
    Checks the syntax of command line arguments and returns the filenames.
    If any switches are unknown, it exits with an error.
Parameters:
    I   int argc                        count of command line arguments
    I   char *argv[]                    array of command line arguments
    O   char **ppszFileData     customer transaction file name
    O   char **ppszFileOut      library book file name
Notes:
    If a -? switch is passed, the usage is printed and the program exits
    with USAGE_ONLY.
    If a syntax error is encountered (e.g., unknown switch), the program
    prints a message to stderr and exits with ERR_COMMAND_LINE_SYNTAX.
**************************************************************************/
void processCommandSwitches(int argc, char *argv[], char **ppszFileData, char **ppszFileOut)
{
    int i; 

    for (i = 1; i < argc; i++)
    {
        // check for a switch
        if (argv[i][0] != '-')
            exitUsage(i, ERR_EXPECTED_SWITCH, argv[i]);
        // determine which switch it is
        switch (argv[i][1])
        {
            case 'i':                   // Customer Transaction File Name switch
                if (++i >= argc)
                    exitUsage(i, ERR_MISSING_ARGUMENT, argv[i - 1]);
                else
                    *ppszFileData = argv[i];
                break;
            
            case 'o':                   // Customer Transaction File Name switch
                if (++i >= argc)
                    exitUsage(i, ERR_MISSING_ARGUMENT, argv[i - 1]);
                else
                    *ppszFileOut = argv[i];
                break;
            
            case '?':
                exitUsage(USAGE_ONLY, "", "");
                break;
            default:
                exitUsage(i, ERR_EXPECTED_SWITCH, argv[i]);
        }
        
        // Used for debugging purposes making sure pointer are pointing to correct file name
        // printf("\nInput file name: %s\nOutput book file name: %s\n", *ppszFileData
        //      , *ppszFileOut); 
        
    }
}

/******************** exitError *****************************
    void exitError(char *pszMessage, char *pszDiagnosticInfo)
Purpose:
    Prints an error message and diagnostic to stderr.  Exits with
    ERROR_PROCESSING.
Parameters:
    I char *pszMessage              error message to print
    I char *pszDiagnosticInfo       supplemental diagnostic information
Notes:
    This routine causes the program to exit.
**************************************************************************/
void exitError(char *pszMessage, char *pszDiagnosticInfo)
{
    fprintf(stderr, "Error: %s %s\n"
        , pszMessage
        , pszDiagnosticInfo);
    exit(ERROR_PROCESSING);
}
/******************** exitUsage *****************************
    void exitUsage(int iArg, char *pszMessage, char *pszDiagnosticInfo)
Purpose:
    If this is an argument error (iArg >= 0), it prints a formatted message
    showing which argument was in error, the specified message, and
    supplemental diagnostic information.  It also shows the usage. It exits
    with ERR_COMMAND_LINE_SYNTAX.

    If this is just asking for usage (iArg will be -1), the usage is shown.
    It exits with USAGE_ONLY.
Parameters:
    I int iArg                      command argument subscript
    I char *pszMessage              error message to print
    I char *pszDiagnosticInfo       supplemental diagnostic information
Notes:
    This routine causes the program to exit.
**************************************************************************/
void exitUsage(int iArg, char *pszMessage, char *pszDiagnosticInfo)
{
    if (iArg >= 0)
        fprintf(stderr, "Error: bad argument #%d.  %s %s\n"
            , iArg
            , pszMessage
            , pszDiagnosticInfo);
    fprintf(stderr, "run -input InputFile -output OutputFile\n");
    if (iArg >= 0)
        exit(-1);
    else
        exit(-2);
}

#include <stdio.h>

void set_array_rand(int x[], int n);
int rand_int(int a,int b);
void SELECTION_SORT(int x[], int n);
void MERGE(int a[], int na, int b[], int nb, int c[], int nc);
void PRINT_ARRAY(char *name, int x[], int nx);

int main(void) 
{
	/* 1. Declare three integer arrays as follows */
	int a[50], b[70], c[120];
	
	/* 2. implement a function set_array_rand(int x[], int n) and call it to generate the values in array a and b randomly. */
	set_array_rand(a, 50);
	set_array_rand(b, 70);
	
	PRINT_ARRAY("Array a", a, 50);
	PRINT_ARRAY("Array b", b, 70);
	
	/* 3. using the SELECTION_SORT(double x[], int n) function (see ch02.ppt), sort the elements in a and b arrays. */
	SELECTION_SORT(a, 50);
	SELECTION_SORT(b, 70);
	
	PRINT_ARRAY("(Selection Sort)... Array a", a, 50);
	PRINT_ARRAY("(Selection Sort)... Array b", b, 70);
	
	/* 4. implement a MERGE function and call it as follows to merge the values in arrays a and b into array c such 
	that the values in c will be sorted after merging */
	
	MERGE(a, 50, b, 70, c, 120);
	
	/* 5. print the values in array c */
	PRINT_ARRAY("(Merge)... Array c", c, 120);
}

void set_array_rand(int x[], int n)
{
	/* 1. randomly generate elements of x array, e.g, */
	int i;
        for(i=0; i< n; i++)
		x[i] = rand_int(30, 100);
}

int rand_int(int a,int b)
{
	return rand()%(b-a+1) + a;
}

void SELECTION_SORT(int x[], int n)
{
	/* x[0] to x[n-1] is the array to sort */
	int i,j,temp;
	
	/* advance the position through the entire array */
	/*   (could do j < n-1 because single element is also min element) */
	for (j = 0; j < n-1; j++) 
	{
	    /* find the min element in the unsorted a[j .. n-1] */
	    /* assume the min is the first element */
	    int iMin = j;
	    
	    /* test against elements after j to find the smallest */
	    for ( i = j+1; i < n; i++) {
	        /* if this element is less, then it is the new minimum */
	        if (x[i] < x[iMin]) 
	        {
	            /* found new minimum; remember its index */
	            iMin = i;
	        }
	    }
	
		/* test if iMin is still the same, if not swap new iMin with current j value */
	    if(iMin != j) {
	       //printf("\t|| x[j]: %d, j: %d, x[iMin]: %d, iMin: %d\n", x[j], j, x[iMin], iMin); // value check
	       temp = x[j];
	       x[j] = x[iMin];
	       x[iMin] = temp;
	    }
	}
}
void MERGE(int a[], int na, int b[], int nb, int c[], int nc)
{
	/* merge the values in a and b into c while keeping the values
	sorted. For example, suppose we have the following two
	Arrays a = { 3, 7, 9, 12} and b = {4, 5, 10}
	When we merge these two arrays, we will get
	c = {3, 4, 5, 7, 9, 10, 12}
	*/
	
	/* create 2 indeces, one for each array */
	int i, j;
	i = j = 0;

	while(i < na || j < nb)	/* while either array has not been fully counted through proceed */
	{
		/* If the number in 1st array is less than the number in the 2nd array add it to c[].
			Then, increment the index for that array */
		if(a[i] < b[j] || j == nb)
			c[i+j] = a[i++];		// updating c with i + j index relationship
		else                                    // otherwise add 2nd array element to c and increment corresponding counter
			c[i+j] = b[j++];		// updating index using post-increment (j = j + 1 AFTER j is used)
	}
}

void PRINT_ARRAY(char *name, int x[], int nx)
{
	int i;
	printf("%s:", name);
	
	for(i = 0; i < nx - 1; i++)
	{
                /* add tab + new line after every 10 values have been outputted */
		if((i%10) == 0)
			printf("\n\t");
		
		printf("%d, ", x[i]);
	}
	printf("%d\n\n", x[i]);
}

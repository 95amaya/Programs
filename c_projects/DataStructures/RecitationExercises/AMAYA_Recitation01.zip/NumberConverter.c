#include <stdio.h>

void printNum(int iValue, int iCount);
void PrintHundreds(int iHundred);
void PrintTens(int iTens, int iCount); 
void PrintOnesDigit(int d); 
void PrintTeensDigit(int d);
void PrintTensDigit(int d); 

const char *ones[10]={"", "one", "two", "three", "four",
				"five", "six", "seven", "eight", "nine"};

const char *teens[10]={"ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
				"sixteen", "seveteen", "eighteen", "nineteen"};

const char *tens[10]={"", "", "twenty", "thirty", "fourty", "fifty",
				"sixty", "sevety", "eighty", "ninety"};

int main(void)
{
    int iInput = 0;
    int iCount = 0;
    int iScanfCount = 0;
   
    printf("Enter Number between -1 and 1 million non inclusively\n");
    
    while(1)
    {
        iInput = iCount = iScanfCount = 0; // reset variables
        printf("Enter Number (-1 to cancel): ");
        iScanfCount = scanf("%d", &iInput); // Enter input using scanf()

        if(iInput == -1) // Exit program case
        {   
            printf(" %d = Exit Program\n", iInput);
            break;
        }
        
        else if(iScanfCount == 0) // Invalid number case (flush buffer out before continuing)
        {
            printf("Invalid Integer try again\n");
            printf(" %d = ", iInput);
            int c;
            while((c = getchar()) != '\n' && c != EOF);
            continue;
        }
        
        else if(iInput < -1 || iInput >= 1000000) // Out of range case (continue)
        {
            printf(" %d = ", iInput);
            printf("Out of range try again\n");
            continue;
        }
        
        else    // Valid number case -> print number
        {
            printf(" %d = ", iInput);
            printNum(iInput, iCount);
    	    printf("\n");
            int c;
            while((c = getchar()) != '\n' && c != EOF); // Flush out buffer in case of letters after number
        }
    } 

    return 0;
}

/********************************************************************************
void printNum(int iValue, int iCount)

Purpose: 
    Takes in user inputted value and recursive iteration 
step in order to process and return the iValue number in a
written format.

Comments:
    Recursive method that divides by 100 then by 10 in 
an alternating fashion breaking up the number as such

ex -> 123456 - Inputted value
    = 1234 after 1st iteration where 56 will be processed last
    = 123  after 2nd iteration where  4 will be processed 2nd to last 
    = 1    after 3rd iteration where 23 will be processed 3rd to last
    returns                    where 1  is processed first
    
    return sequence -- iCount is used to keep track of digit place for hundred and thousands 
    1  -> one hundred
    23 -> twenty three thousand
    4  -> four hundred
    56 -> fifty six



***********************************************************************************/
void printNum(int iValue, int iCount)
{
   // printf("iCount = %d ", iCount);
    
    if(iCount % 2 == 0) // On even sequences break up number by 100
    {
    	if(iValue - 100 < 0) // base case
    	{
    	    PrintTens(iValue % 100, iCount); // print left most number first
    	    return;
    	}
    	printNum(iValue / 100, ++iCount); // Get to left most number first
     
        if(iCount >= 3)
            PrintTens(iValue % 100, --iCount); // Print tens + ones place of number
        else 
            PrintTens(iValue % 100, iCount); // Print tens + ones place of number
    }
    else // odd sequences break up number by 10
    {
    //    printf(" iCounthundreds = %d ", iCount);
    	if(iValue - 10 < 0) // base case
    	{
    	    PrintHundreds(iValue % 10); // print left most number first
    	    return;
    	}
    	printNum(iValue / 10, ++iCount); // Get to the left most number first
    	
    	PrintHundreds(iValue % 10);  // print hundreds place for number
    }
}

/**************************************************************************
void PrintTens(int iTens, int iCount)

Purpose:
    prints the tens + ones place of the value in that number by getting
the tens place and ones place respectively and using some logic to break
up how to print each.


**************************************************************************/
void PrintTens(int iTens, int iCount) // passes a value 00..99
{
    int tens, ones;
    tens = ones = 0;
	
//    printf(" iCounttens = %d ", iCount);
    
    if(iTens == 0 && iCount == 0) // zero case
	printf("Zero");
    else if(iTens >= 10)        // > 9 case for tens place variable
	tens = iTens / 10;
	
    ones = iTens % 10;          // gets one place of value
	
    if(tens > 1) // >= 20
    {
        PrintTensDigit(tens);
        if(ones != 0)
            PrintOnesDigit(ones); 
    }
    else if(tens == 1) // teens
    {
    	PrintTeensDigit(ones);
    }
    else if(tens == 0) // ones
    {
    	if(ones != 0)
	    PrintOnesDigit(ones);
    }
	
    if(iCount == 2) // When to print thousand
        printf("thousand ");
        

}

void PrintHundreds(int iHundred) // prints hundred place
{
    if(iHundred > 0)
    {
        PrintOnesDigit(iHundred);
        printf("hundred ");
    }
}

void PrintOnesDigit(int d) // prints ones place 0 - 9 as string
{
    if (d>=1 && d<=9)
	printf("%s ", ones[d]);
    else
	printf("Illegal call to PrintOneDigit");
}

void PrintTeensDigit(int d) // prints teens place 10 - 19 as string
{
    if (d>=0 && d<=9)
    	printf("%s ", teens[d]);
    else
	printf("Illegal call to PrintTeensDigit");
}

void PrintTensDigit(int d) // prints tens place 20, 30, 40, ..., 80, 90 as string
{
    if (d>=2 && d<=9)
	printf("%s ", tens[d]);
    else
	printf("Illegal call to PrintTensDigit");
}
